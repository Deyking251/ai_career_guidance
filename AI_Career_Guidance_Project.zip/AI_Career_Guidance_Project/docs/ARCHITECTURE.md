# System Architecture

```text
Student
   |
   v
Streamlit Web UI
   |
   +--> Student Profile
   |
   +--> Career Recommendation
   |       |
   |       v
   |   TF-IDF Vectorizer
   |       |
   |       v
   |   Cosine Similarity
   |
   +--> Skill Gap Engine
   |       |
   |       v
   |   Required Skills - Student Skills
   |
   +--> Learning Roadmap
   |
   +--> Job Recommendation
   |       |
   |       v
   |   TF-IDF + Location Boost
   |
   +--> Resume Analyzer
           |
           v
       PDF text extraction
           |
           v
       Skill keyword matching

Data Layer:
- data/careers.csv
- data/jobs.csv
