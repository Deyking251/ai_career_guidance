# AI-Powered Career Guidance and Skill Gap Analysis System

AICTE/IBM SkillsBuild internship project.

## Goal
Recommend suitable career roles from a student's skills/interests, identify missing skills, recommend a learning roadmap, and match the student to sample job roles.

## Technology
- Python
- Streamlit
- Pandas
- Scikit-learn
- TF-IDF + cosine similarity
- Optional PDF resume text extraction with pypdf

## Run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Ubuntu/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Open the URL shown by Streamlit.

## Important
The included job data is a demonstration dataset for the internship prototype. It is not a live job board.
